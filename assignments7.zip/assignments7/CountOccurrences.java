/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.Scanner;
public class CountOccurrences {
    public int countOccurrences(int n, int []arr,int x)       
    {
        int count=0;
        for (int i = 0; i < n; i++) {
            if(arr[i]==x)
            {
                count++;
            }
        }
        return count;
    }
    public static void main(String[] args) {
        CountOccurrences c=new CountOccurrences();
        Scanner scanner =new Scanner(System.in);
        System.out.print("Enter number Array ");
        int n=scanner.nextInt();
        int []arr=new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Array["+i+"]= ");
            arr[i]=scanner.nextInt();
        }
        System.out.print("Enter digits probably appear at array: ");
        
        int x=scanner.nextInt();
        System.out.println("number appear in array "+c.countOccurrences(n,arr,x));
    }
}
