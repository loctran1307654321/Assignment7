/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;
public class ToDoListManagement {
    public static void main(String[] args) {
        Scanner scanner =new Scanner(System.in);
        ArrayList<String> arr=new ArrayList<>();
        while(true)
        {
            System.out.println("The program should allow the user to: ");
            System.out.println("1. Add a new task. ");
            System.out.println("2. View all tasks. ");
            System.out.println("3. Remove a task by its position (index). ");     
            
            int n=scanner.nextInt();
            switch(n)
            {
                case 1: 
                    arr.add(scanner.next());
                    break;
                case 2:
                    System.out.println(Arrays.toString(arr.toArray()));break;
                case 3:
                    arr.remove(scanner.nextInt());break;
                
                    
                default:
                    scanner.close();
                    return ;
            }
        }
            
     
    }
}
