/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;
public class FilterEvenNumbers {
    public static ArrayList<Integer> evenArr(int n,int []arr)
    {
        ArrayList<Integer> arrL=new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if(arr[i]%2==0)
            {
                arrL.add(arr[i]);
            }
        }
        return arrL;
    }
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter number of array: ");
        ArrayList<Integer> arrL=new ArrayList<>();
        int n= scanner.nextInt();
        int []arr=new int[10];
        for (int i = 0; i < n; i++) {  
            System.out.println("Array["+i+"]=");
            arr[i]=scanner.nextInt();
        }
        System.out.print("even number of array is: ");
        arrL=evenArr(n,arr);
        System.out.println(Arrays.toString(arrL.toArray()));
        
                
    }
}
