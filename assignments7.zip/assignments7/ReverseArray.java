
package assignments7;

import java.util.Scanner;
public class ReverseArray {
    static int []arr;
    public  void display(int n,int []arr)
    {
        for (int i = 0; i < n; i++)
        {
            System.out.println("Array["+i+"]= "+arr[i]);
        }
    }
    public  void reverse(int n,int []arr)
    {
        int num; 
        ReverseArray r=new ReverseArray();
        for (int i = 0; i < n/2; i++) {
           num =arr[i]+arr[n-1-i];
           arr[i]=num-arr[i];
           arr[n-i-1]=num-arr[n-1-i];
        }
   
    }
    public static void main(String[] args) {
        Scanner scanner =new Scanner(System.in);
        System.out.println("Enter n:"); 
        ReverseArray r=new ReverseArray();
        int n=scanner.nextInt(); 
        arr=new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Array["+i+"]= ");
            arr[i]=scanner.nextInt();
        }
        r.reverse(n,arr);
        r.display(n,arr);
        
    }
}
