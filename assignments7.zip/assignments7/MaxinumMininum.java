/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.Scanner;

public class MaxinumMininum {
    public static void main(String[] args) {
       Scanner scanner =new Scanner(System.in);
        System.out.println("Enter number of array: ");
        int n=scanner.nextInt();
        int []arr=new int[n]; 
        System.out.print("Enter Array["+0+"]= ");
        arr[0]=scanner.nextInt();
        int max=arr[0];
        int min=arr[0];
        for (int i =1; i < n; i++) {
            System.out.print("Enter Array["+i+"]= ");
            arr[i]=scanner.nextInt();
            if(arr[i]>max)
            {
                max=arr[i];
            }else
            {
                if(arr[i]<min)
                {
                    min=arr[i];
                }
            }
        }
        System.out.println("maxinum of array is "+max+ " and mininum of array is: "+min);
        
    }
}
